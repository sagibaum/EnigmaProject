package Main.Client.ContestTabController;

import EngineFunctionallity.EngineObject;
import Exceptions.InValidUserInputException;
import Main.Client.ContestTabController.Candidates.CandidatesController;
import Main.Client.ContestTabController.DictionaryList.DictionaryListController;
import Main.Client.ContestTabController.DictionarySearch.DictionarySearchController;
import Main.Client.ContestTabController.Encrypt.InputArea.InputAreaController;
import Main.Client.ContestTabController.Encrypt.ResultsArea.ResultsAreaController;
import ServerDTOs.Uboat.TableDataObject;
import Main.Client.UBoatClientController;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import user.data.transfer.unit.UserDataTransferUnit;

import java.util.ArrayList;
import java.util.Set;
import java.util.StringTokenizer;

public class UBoatContestController {

    @FXML
    private Button LogOutButton;

    @FXML
    private Label ArrowLabel;

    @FXML
    private Button ProcessButton;

    @FXML
    private Button ClearButton;

    @FXML
    private Button ResetButton;

    @FXML
    private ToggleButton ReadyButton;

    @FXML
    private TextField MachineConfTextField;

    @FXML
    private TableView<TableDataObject> ActiveTeamsTable;

    @FXML TableColumn<TableDataObject,String>  alliesNameCol;
    @FXML TableColumn<TableDataObject,String>  numOfAgentsCol;
    @FXML TableColumn<TableDataObject,String>  missionSizeCol;
    @FXML TableColumn<TableDataObject,String>  readyStatusCol;

    @FXML private ScrollPane TableScrollPane;

    @FXML private TextArea ResultsComponent,InputComponent;

    @FXML private FlowPane CandidatesComponent;

    @FXML ListView<String> DictionaryListComponent;

    @FXML HBox DictionarySearchComponent;

    @FXML private DictionarySearchController DictionarySearchComponentController;
    @FXML private DictionaryListController DictionaryListComponentController;
    @FXML private ResultsAreaController ResultsComponentController;
    @FXML private InputAreaController InputComponentController;
    @FXML private CandidatesController CandidatesComponentController;

    private UBoatClientController fatherController;
    private EngineObject Engine;
    UserDataTransferUnit UICommunicationUnit;

    private String message;


    public void setContestTab(UBoatClientController uBoatClientController,EngineObject engine,UserDataTransferUnit userDataTransferUnit){
        //AlliesTable = new TableView<TableDataObject>(); // for saving Allies info from server .
        this.UICommunicationUnit=userDataTransferUnit;
        this.Engine=engine;
        this.fatherController = uBoatClientController;
        ReadyButton.getStylesheets().add(String.valueOf((getClass().getResource("ReadyButton.css".toString()))));
        message = "";
        setAlliesTable();//sets table observable properties

    }


    private void  setAlliesTable(){
        ActiveTeamsTable = new TableView<>();
        ActiveTeamsTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        alliesNameCol.setCellValueFactory(new PropertyValueFactory<>("allyName")); //Ally name set up
        numOfAgentsCol.setCellValueFactory(new PropertyValueFactory<>("agentsNum"));//Agents num set up
        missionSizeCol.setCellValueFactory(new PropertyValueFactory<>("missionSize"));//Mission size num set up
        readyStatusCol.setCellValueFactory(new PropertyValueFactory<>("readyStatus"));//Ready status num set up
        alliesNameCol.setStyle("-fx-alignment: CENTER;");
        numOfAgentsCol.setStyle("-fx-alignment: CENTER;");
        missionSizeCol.setStyle("-fx-alignment: CENTER;");
        readyStatusCol.setStyle("-fx-alignment: CENTER;");
        ActiveTeamsTable.getColumns().addAll(alliesNameCol,numOfAgentsCol,missionSizeCol,readyStatusCol);
        TableScrollPane.setContent(ActiveTeamsTable);
    }
    public void setDictionaryListViewComponentController(){
        this.DictionaryListComponentController.setController(this,Engine.getDecipher().getDictionary().getDictionaryWords());
    }

    public void setDictionaryHBoxComponentController(){
        this.DictionarySearchComponentController.setController(this,Engine);
    }
    public TextField getMachineConfTextField() {
        return MachineConfTextField;
    }

    public boolean CompareInputTextAreaField(String compare){
        return InputComponentController.CompareFieldText(compare);
    }
    public void setInputTextArea(String word){
        InputComponentController.setInputTextArea(word);
    }
    public String getInputTextArea(){
        return InputComponentController.getInputTextAreaText();
    }

    public String getWordSelectedFromListView(){
        return DictionaryListComponentController.getWordSelectedFromList();
    }

    public void addSetToListView(Set<String> resDict ){
        DictionaryListComponentController.setT3DictionaryListView(resDict);
    }
    public void clearListView(){
        DictionaryListComponentController.clearT3DictionaryListView();
    }


    @FXML
    void processMessage(MouseEvent event) {
        Alert alert;
        if(Engine.isMachineNull())
        {
            alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("Machine not set yet!");
            alert.setContentText("Please first configure the machine");
            alert.showAndWait();
        }
        else if(!Engine.isPlugBoardEmpty())
        {
            alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("Plugboard is NOT empty");
            alert.setContentText("The task assumes that the plugboard must be empty\n Please reconfigure the machine.");
            alert.showAndWait();
        }
        else if( CompareInputTextAreaField("")) {
            alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("Message box is empty!");
            alert.setContentText("Please enter a message you want to decipher");
            alert.showAndWait();
        }
        else{
            alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("Encryption Error");
            if (!Engine.isMachineNull()) {
                try {
                    checkUserInputIsFromDictionary(InputComponentController.getInputTextAreaText().toUpperCase());
                    String beforeEnc = InputComponentController.getInputTextAreaText();
                    String encrypted = Engine.InputEncryptionOrDecoding(InputComponentController.getInputTextAreaText().toUpperCase(), UICommunicationUnit, false);
                    this.message = encrypted;
                    fatherController.setCurrMachineConfTextArea(UICommunicationUnit.getCurrentMachineConfiguration());
                    String res = "Before Encryption:\n------\n" + beforeEnc + "\n------\nAfter Encryption:\n" + encrypted;
                    ResultsComponentController.setEncryptResultTextArea(res);
                    InputComponentController.clearInputTextArea();
                    ProcessButton.setDisable(true);
                    ResetButton.setDisable(false);
                    ClearButton.setDisable(true);
                    DictionaryListComponentController.setDictionaryListViewDisable(true);
                    DictionarySearchComponentController.setT3WordSearchTextFieldDisabled(true);
                    ReadyButton.setDisable(false);
                    updateCompetitionDetails();
                } catch (InValidUserInputException e) {
                    alert.setContentText(e.getCause().getMessage());
                    alert.showAndWait();
                }
            }
        }
    }

    private void checkUserInputIsFromDictionary(String input) {// checking valid inputs!
        StringTokenizer st = new StringTokenizer(input, " ");
        String caus = "";
        while (st.hasMoreTokens()) {
            String temp = st.nextToken();
            if (!Engine.getDecipher().getDictionary().getDictionaryWords().contains(temp)) {
                caus += temp + " , ";
            }
        }
        if(!caus.equals("")) throw new InValidUserInputException("These word isn't belong to dictionary: "+caus);
    }

    @FXML
    void clearFields(MouseEvent event) {
        InputComponentController.clearInputTextArea();
    }

    @FXML
    void resetMachineToInitial(MouseEvent event) {
        Engine.ResetCode(UICommunicationUnit);
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        UICommunicationUnit.setMachineConfBeforeEncryption(UICommunicationUnit.getCurrentMachineConfiguration());
        fatherController.clearCurrMachineConfTextArea();
        fatherController.setCurrMachineConfTextArea(UICommunicationUnit.getCurrentMachineConfiguration());
        ProcessButton.setDisable(false);
        ReadyButton.setDisable(true);
        ResultsComponentController.clearTextArea();
        InputComponentController.clearInputTextArea();
        DictionarySearchComponentController.clearSearchField();
        DictionaryListComponentController.setDictionaryListViewDisable(false);
        DictionarySearchComponentController.setT3WordSearchTextFieldDisabled(false);
        alert.setHeaderText("Code resets successfully!");
        alert.showAndWait();
    }


    @FXML void LogOut(MouseEvent event) {//when logout button is pressed
        fatherController.logout();// main controller will accomplish the logout process
    }

    void buttonFunctionalityUnpressed(){
        ReadyButton.setStyle("-fx-background-color:green");
        ReadyButton.setText("Ready!");

    }

    void buttonFunctionalityPressed(){
        ReadyButton.setStyle("-fx-background-color:red");
        ReadyButton.setText("Unready :(");

    }

    @FXML public void ReadyUnReadyCompetition(ActionEvent actionEvent) {

        if(!ReadyButton.isSelected()) // means that user wants to do unready process
        {
            //send to the server that he isn't ready! -> same servlet as the ready but without body of machine ,dictionary and so ..
            System.out.println("Announcing that i am not ready now");
            buttonFunctionalityUnpressed();
            fatherController.sendServerReadyNotice(false);
        }


        else // user announce the server that he is ready
        {
            buttonFunctionalityPressed();
            System.out.println("Announcing that i am ready now");
            fatherController.sendServerReadyNotice(true);
        }
    }

    private void  updateCompetitionDetails(){ // updates server contest details
        ArrayList<String> MachineInfo = new ArrayList<String>();
        MachineInfo.add(MachineConfTextField.getText());//adding machine conf
        MachineInfo.add(message);//adding the message after encrypted
        fatherController.setMessageOfTheCompetition(MachineInfo);//father will send the data to server
        //if server response is ok the father controller will call a function here to make all other components disable

    }


    public void addAlliesDetails(ArrayList<TableDataObject> allyRowsArr){
        ObservableList<TableDataObject> data = FXCollections.observableArrayList();
        data.addAll(allyRowsArr);// add all to the
        ActiveTeamsTable.setItems(data);
    }

    public void UpdateContestTabDisabilityComponents(boolean ready) {
            DictionaryListComponentController.setDictionaryListViewDisable(ready);
            DictionarySearchComponentController.setT3WordSearchTextFieldDisabled(ready);
            ProcessButton.setDisable(ready);
            ClearButton.setDisable(ready);
            InputComponent.setDisable(ready);
            LogOutButton.setDisable(ready);

    }
}
